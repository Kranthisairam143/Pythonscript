import pytesseract
from PIL import Image

def compare_images(img1, img2, threshold=50):
    width, height = img1.size
    img2 = img2.resize((width, height))
    img1_gray = img1.convert("L")
    img2_gray = img2.convert("L")
    mask = Image.new("1", (width, height), 0)
    for x in range(width):
        for y in range(height):
            if abs(img1_gray.getpixel((x, y)) - img2_gray.getpixel((x, y))) > threshold:
                mask.putpixel((x, y), 1)

    return mask

def extract_answers(question_paper_path, answer_sheet_path, threshold=50):
    question_paper_img = Image.open(question_paper_path)
    answer_sheet_img = Image.open(answer_sheet_path)

    mask = compare_images(question_paper_img, answer_sheet_img, threshold)

    answer_sheet_text = pytesseract.image_to_string(answer_sheet_img, config="--psm 6")
    answers = []
    lines = answer_sheet_text.split("\n")
    for i in range(len(lines)):
        if mask.getpixel((0, i)):
            answer = lines[i].strip()
            if answer:
                answers.append(answer)

    return answers

if __name__ == "__main__":
    question_paper_path = "C:\\Users\\DELL\\Downloads\\Fill in the blanks empty sheet.jpg"
    answer_sheet_path = "C:\\Users\\DELL\\Downloads\\Fill in the blanks answe1.jpeg"


    extracted_answers = extract_answers(question_paper_path, answer_sheet_path)

    print("Extracted Answers:")
    for i, answer in enumerate(extracted_answers, 1):
        print(f"ans{i}: {answer}")
